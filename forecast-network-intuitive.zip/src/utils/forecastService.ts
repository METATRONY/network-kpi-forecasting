import { supabase } from '@/lib/supabase';
import { CSVRow } from './csvParser';

interface ForecastRequest {
  model: string;
  data: CSVRow[];
  dateColumn: string;
  kpiColumn: string;
  forecastPeriods?: number;
  trainPercentage?: number;
}

interface ForecastResponse {
  predictions: Array<{
    date: Date;
    value: number;
  }>;
  metrics: {
    rmse: number;
    mae: number;
    mape: number;
  };
  model: string;
  success: boolean;
  validationData?: Array<{
    date: Date;
    actualValue: number;
    predictedValue: number;
  }>;
}

const checkBackendAccess = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.functions.invoke('forecast-models', {
      body: { action: 'health-check' }
    });
    
    if (error) {
      console.error('Backend access check failed:', error);
      return false;
    }
    
    return data?.status === 'healthy';
  } catch (error) {
    console.error('Backend access check error:', error);
    return false;
  }
};

export const runForecastModel = async (request: ForecastRequest): Promise<ForecastResponse> => {
  const hasBackendAccess = await checkBackendAccess();
  
  if (!hasBackendAccess) {
    throw new Error('Backend forecast service is not accessible. Cannot run forecast calculations on simulated data.');
  }

  try {
    const numericData = request.data.filter(row => {
      const value = row[request.kpiColumn];
      return value !== null && value !== undefined && value !== '' && !isNaN(parseFloat(String(value)));
    });

    if (numericData.length === 0) {
      throw new Error(`No valid numeric data found in KPI column '${request.kpiColumn}'.`);
    }

    const kpiValues = numericData.map(row => parseFloat(String(row[request.kpiColumn])));
    const dataStats = {
      min: Math.min(...kpiValues),
      max: Math.max(...kpiValues),
      mean: kpiValues.reduce((a, b) => a + b, 0) / kpiValues.length,
      count: kpiValues.length
    };

    const { data, error } = await supabase.functions.invoke('forecast-models', {
      body: {
        model: request.model,
        data: numericData,
        dateColumn: request.dateColumn,
        kpiColumn: request.kpiColumn,
        forecastPeriods: request.forecastPeriods || 288,
        trainPercentage: request.trainPercentage || 80,
        dataStats
      }
    });

    if (error) {
      throw new Error(`Forecast error: ${error.message}`);
    }

    if (!data.success) {
      throw new Error(data.error || 'Forecast failed');
    }

    return {
      predictions: data.predictions.map((p: any) => ({
        date: new Date(p.date),
        value: p.value
      })),
      metrics: data.metrics,
      model: data.model,
      success: true,
      validationData: data.validationData?.map((v: any) => ({
        date: new Date(v.date),
        actualValue: v.actualValue,
        predictedValue: v.predictedValue
      }))
    };
  } catch (error) {
    console.error('Forecast service error:', error);
    throw error;
  }
};

export const generateValidationDataWithCalculatedValue = (
  validationData: Array<{ date: Date; actualValue: number; predictedValue: number }>,
  dateColumn: string,
  kpiColumn: string,
  identifierColumns: string[] = []
): CSVRow[] => {
  const uniqueObjects = identifierColumns.length > 0 ? ['default'] : ['default'];
  const result: CSVRow[] = [];
  
  uniqueObjects.forEach(objectId => {
    validationData.forEach(item => {
      const row: CSVRow = {};
      
      row[dateColumn] = item.date.toISOString().slice(0, 19).replace('T', ' ');
      row[kpiColumn] = item.actualValue.toString();
      row['calculated_value'] = item.predictedValue.toString();
      
      identifierColumns.forEach(col => {
        row[col] = objectId;
      });
      
      result.push(row);
    });
  });
  
  return result;
};