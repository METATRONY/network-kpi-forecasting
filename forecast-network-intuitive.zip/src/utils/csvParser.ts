export interface CSVRow {
  [key: string]: string;
}

export const parseCSV = (csvText: string): { headers: string[]; data: CSVRow[] } => {
  const lines = csvText.trim().split('\n');
  if (lines.length === 0) {
    return { headers: [], data: [] };
  }

  // Parse headers
  const headers = lines[0].split(',').map(header => header.trim().replace(/"/g, ''));
  
  // Parse data rows
  const data: CSVRow[] = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(value => value.trim().replace(/"/g, ''));
    if (values.length === headers.length) {
      const row: CSVRow = {};
      headers.forEach((header, index) => {
        row[header] = values[index];
      });
      data.push(row);
    }
  }

  return { headers, data };
};

export const readFileAsText = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        resolve(e.target.result as string);
      } else {
        reject(new Error('Failed to read file'));
      }
    };
    reader.onerror = () => reject(new Error('Error reading file'));
    reader.readAsText(file);
  });
};

// Helper function to generate 15-minute intervals
const generateFifteenMinuteIntervals = (startDate: Date, count: number): Date[] => {
  const intervals: Date[] = [];
  const current = new Date(startDate);
  
  for (let i = 0; i < count; i++) {
    intervals.push(new Date(current));
    current.setMinutes(current.getMinutes() + 15);
  }
  
  return intervals;
};

// Legacy simulate forecast function (kept for compatibility)
export const simulateForecast = async (data: {
  csvData: CSVRow[];
  dateColumn: string;
  kpiColumn: string;
  identifierColumns: string[];
  trainPercentage?: number;
}): Promise<{
  overallAccuracy: { rmse: number; mae: number; mape: number };
  objectResults: Array<{
    id: string;
    metrics: { rmse: number; mae: number; mape: number };
    chartUrl: string;
  }>;
  predictedData: CSVRow[];
}> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Generate mock results
  const uniqueObjects = data.identifierColumns.length > 0 
    ? [...new Set(data.csvData.map(row => 
        data.identifierColumns.map(col => row[col]).join('-')
      ))]
    : ['default'];

  const objectResults = uniqueObjects.map(id => ({
    id,
    metrics: {
      rmse: Math.random() * 10 + 1,
      mae: Math.random() * 8 + 0.5,
      mape: Math.random() * 15 + 2
    },
    chartUrl: `chart-${id}.png`
  }));

  const overallAccuracy = {
    rmse: objectResults.reduce((sum, obj) => sum + obj.metrics.rmse, 0) / objectResults.length,
    mae: objectResults.reduce((sum, obj) => sum + obj.metrics.mae, 0) / objectResults.length,
    mape: objectResults.reduce((sum, obj) => sum + obj.metrics.mape, 0) / objectResults.length
  };

  // Generate predicted data with 15-minute intervals
  const predictedData: CSVRow[] = [];
  
  // Find the latest date in the dataset to start predictions from
  const latestDate = data.csvData.reduce((latest, row) => {
    const rowDate = new Date(row[data.dateColumn]);
    return rowDate > latest ? rowDate : latest;
  }, new Date(0));
  
  // Start predictions from the next 15-minute interval after the latest date
  const startPredictionDate = new Date(latestDate);
  startPredictionDate.setMinutes(Math.ceil(startPredictionDate.getMinutes() / 15) * 15, 0, 0);
  
  // Create prediction entries for each unique object
  uniqueObjects.forEach(objectId => {
    // Generate 96 predictions (24 hours * 4 intervals per hour) for each object
    const predictionIntervals = generateFifteenMinuteIntervals(startPredictionDate, 96);
    
    predictionIntervals.forEach(intervalDate => {
      const predictedRow: CSVRow = {
        [data.dateColumn]: intervalDate.toISOString().slice(0, 19).replace('T', ' '),
        predicted_value: (Math.random() * 100 + 50).toFixed(3)
      };
      
      // Add identifier columns if they exist
      if (data.identifierColumns.length > 0) {
        const identifierParts = objectId.split('-');
        data.identifierColumns.forEach((col, index) => {
          predictedRow[col] = identifierParts[index] || objectId;
        });
      }
      
      predictedData.push(predictedRow);
    });
  });

  return { overallAccuracy, objectResults, predictedData };
};