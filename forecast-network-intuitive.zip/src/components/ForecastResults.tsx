import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Download, BarChart3, TrendingUp, FileText } from 'lucide-react';
import GrafanaChart from './GrafanaChart';

interface AccuracyMetrics {
  rmse: number;
  mae: number;
  mape: number;
}

interface ObjectResult {
  id: string;
  metrics: AccuracyMetrics;
  chartUrl: string;
}

interface ForecastResultsProps {
  overallAccuracy: AccuracyMetrics | null;
  objectResults: ObjectResult[];
  selectedObject: string;
  setSelectedObject: (objectId: string) => void;
  onDownloadResults: () => void;
  onDownloadPredictions: () => void;
  isLoading: boolean;
  predictedData: Array<{ [key: string]: string }>;
  selectedModel: string;
}

const ForecastResults: React.FC<ForecastResultsProps> = ({
  overallAccuracy,
  objectResults,
  selectedObject,
  setSelectedObject,
  onDownloadResults,
  onDownloadPredictions,
  isLoading,
  predictedData,
  selectedModel
}) => {
  // Update chart when selected object or model changes
  useEffect(() => {
    if (selectedObject && predictedData.length > 0) {
      console.log('Chart update triggered - Object:', selectedObject, 'Model:', selectedModel);
    }
  }, [selectedObject, predictedData, selectedModel]);

  if (!overallAccuracy && objectResults.length === 0 && !isLoading) {
    return null;
  }

  const selectedObjectData = objectResults.find(obj => obj.id === selectedObject);
  
  // Generate chart data for the selected object
  const generateChartData = () => {
    if (!selectedObject || !predictedData.length) return [];
    
    return predictedData
      .filter(row => {
        // Filter data for the selected object
        if (selectedObject === 'default') return true;
        
        // Check if any field in the row matches parts of the selected object ID
        const objectParts = selectedObject.split('-');
        return objectParts.some(part => 
          Object.values(row).some(value => value === part)
        );
      })
      .slice(0, 48) // Show first 12 hours (48 * 15-minute intervals)
      .map((row, index) => {
        // Find date/time column
        const timeKey = Object.keys(row).find(key => 
          key.toLowerCase().includes('time') || 
          key.toLowerCase().includes('date') ||
          key.toLowerCase().includes('datetime')
        );
        
        // Find value column (calculated_value or predicted_value)
        const valueKey = Object.keys(row).find(key => 
          key === 'calculated_value' || 
          key === 'predicted_value' ||
          key.toLowerCase().includes('value')
        );
        
        return {
          timestamp: timeKey ? row[timeKey] : new Date(Date.now() + index * 15 * 60 * 1000).toISOString(),
          value: parseFloat(row[valueKey || 'calculated_value'] || '0')
        };
      });
  };

  const chartData = generateChartData();

  return (
    <Card className="bg-white shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-green-50 to-blue-50 rounded-t-lg">
        <CardTitle className="text-xl font-bold text-slate-800 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          3. Forecasting Results - {selectedModel.toUpperCase()}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
            <span className="ml-3 text-slate-600">Running {selectedModel.toUpperCase()} forecast...</span>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Overall Accuracy */}
            {overallAccuracy && (
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-indigo-600" />
                  Overall Accuracy - {selectedModel.toUpperCase()}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-3 rounded-lg shadow-sm">
                    <div className="text-sm text-slate-600">RMSE</div>
                    <div className="text-xl font-bold text-slate-800">{overallAccuracy.rmse.toFixed(3)}</div>
                  </div>
                  <div className="bg-white p-3 rounded-lg shadow-sm">
                    <div className="text-sm text-slate-600">MAE</div>
                    <div className="text-xl font-bold text-slate-800">{overallAccuracy.mae.toFixed(3)}</div>
                  </div>
                  <div className="bg-white p-3 rounded-lg shadow-sm">
                    <div className="text-sm text-slate-600">MAPE</div>
                    <div className="text-xl font-bold text-slate-800">{overallAccuracy.mape.toFixed(2)}%</div>
                  </div>
                </div>
              </div>
            )}

            {/* Individual Object Results */}
            {objectResults.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-800">Individual Object Results</h3>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Select Object to View</label>
                  <Select value={selectedObject} onValueChange={setSelectedObject}>
                    <SelectTrigger className="border-indigo-200 focus:border-indigo-400">
                      <SelectValue placeholder="Select an object" />
                    </SelectTrigger>
                    <SelectContent>
                      {objectResults.map((obj) => (
                        <SelectItem key={obj.id} value={obj.id}>{obj.id}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedObjectData && (
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="outline" className="bg-white">{selectedObjectData.id}</Badge>
                      <Badge variant="secondary">{selectedModel.toUpperCase()}</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="bg-white p-3 rounded-lg shadow-sm">
                        <div className="text-sm text-slate-600">RMSE</div>
                        <div className="text-lg font-bold text-slate-800">{selectedObjectData.metrics.rmse.toFixed(3)}</div>
                      </div>
                      <div className="bg-white p-3 rounded-lg shadow-sm">
                        <div className="text-sm text-slate-600">MAE</div>
                        <div className="text-lg font-bold text-slate-800">{selectedObjectData.metrics.mae.toFixed(3)}</div>
                      </div>
                      <div className="bg-white p-3 rounded-lg shadow-sm">
                        <div className="text-sm text-slate-600">MAPE</div>
                        <div className="text-lg font-bold text-slate-800">{selectedObjectData.metrics.mape.toFixed(2)}%</div>
                      </div>
                    </div>
                    
                    {/* Grafana-style Chart */}
                    {chartData.length > 0 ? (
                      <GrafanaChart
                        key={`${selectedObjectData.id}-${selectedModel}-${chartData.length}`}
                        objectId={selectedObjectData.id}
                        data={chartData}
                        title={`${selectedModel.toUpperCase()} Forecast - ${selectedObjectData.id}`}
                      />
                    ) : (
                      <div className="bg-white p-4 rounded-lg border-2 border-dashed border-slate-200">
                        <div className="text-center text-slate-500">
                          <BarChart3 className="w-12 h-12 mx-auto mb-2 text-slate-400" />
                          <p>No chart data available for {selectedObjectData.id}</p>
                          <p className="text-sm">(Run forecast to generate chart data)</p>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Download Results */}
            <div className="pt-4 border-t">
              <div className="flex flex-wrap gap-3">
                <Button 
                  onClick={onDownloadResults}
                  className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Download All Results
                </Button>
                
                <Button 
                  onClick={onDownloadPredictions}
                  className="bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
                  disabled={predictedData.length === 0}
                >
                  <FileText className="w-4 h-4" />
                  Download Predictions
                </Button>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ForecastResults;