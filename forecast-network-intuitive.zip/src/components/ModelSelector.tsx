import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (model: string) => void;
}

const FORECASTING_MODELS = [
  { value: 'arima', label: 'ARIMA', description: 'AutoRegressive Integrated Moving Average' },
  { value: 'exponential_smoothing', label: 'Exponential Smoothing', description: 'Simple exponential smoothing' },
  { value: 'sarima', label: 'SARIMA', description: 'Seasonal ARIMA' },
  { value: 'prophet', label: 'Prophet', description: 'Facebook Prophet model' },
  { value: 'linear_regression', label: 'Linear Regression', description: 'Linear regression model' },
  { value: 'ridge', label: 'Ridge', description: 'Ridge regression' },
  { value: 'lasso', label: 'Lasso', description: 'Lasso regression' },
  { value: 'random_forest', label: 'Random Forest', description: 'Random Forest ensemble' },
  { value: 'gradient_boosting', label: 'Gradient Boosting', description: 'Gradient Boosting Machines' }
];

const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onModelChange }) => {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Select Forecasting Model</CardTitle>
        <CardDescription>
          Choose the machine learning model for your time series forecast
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="model-select">Forecasting Model</Label>
          <Select value={selectedModel} onValueChange={onModelChange}>
            <SelectTrigger id="model-select">
              <SelectValue placeholder="Select a forecasting model" />
            </SelectTrigger>
            <SelectContent>
              {FORECASTING_MODELS.map((model) => (
                <SelectItem key={model.value} value={model.value}>
                  <div className="flex flex-col">
                    <span className="font-medium">{model.label}</span>
                    <span className="text-sm text-muted-foreground">{model.description}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModelSelector;