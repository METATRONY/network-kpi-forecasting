import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3 } from 'lucide-react';

interface GrafanaChartProps {
  objectId: string;
  data: Array<{
    timestamp: string;
    value: number;
  }>;
  title?: string;
}

const GrafanaChart: React.FC<GrafanaChartProps> = ({ objectId, data, title }) => {
  // Simulate Grafana-style chart rendering
  const maxValue = Math.max(...data.map(d => d.value));
  const minValue = Math.min(...data.map(d => d.value));
  const range = maxValue - minValue;

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-slate-700 flex items-center gap-2">
          <BarChart3 className="w-4 h-4" />
          {title || `Forecast Chart - ${objectId}`}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="relative h-64 bg-slate-50 rounded border">
          {/* Y-axis labels */}
          <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-xs text-slate-500 pr-2">
            <span>{maxValue.toFixed(1)}</span>
            <span>{((maxValue + minValue) / 2).toFixed(1)}</span>
            <span>{minValue.toFixed(1)}</span>
          </div>
          
          {/* Chart area */}
          <div className="ml-8 h-full relative">
            {/* Grid lines */}
            <div className="absolute inset-0">
              {[0, 25, 50, 75, 100].map(percent => (
                <div
                  key={percent}
                  className="absolute w-full border-t border-slate-200"
                  style={{ top: `${percent}%` }}
                />
              ))}
            </div>
            
            {/* Data points and line */}
            <svg className="absolute inset-0 w-full h-full">
              {data.map((point, index) => {
                const x = (index / (data.length - 1)) * 100;
                const y = 100 - ((point.value - minValue) / range) * 100;
                
                return (
                  <g key={index}>
                    {/* Line to next point */}
                    {index < data.length - 1 && (
                      <line
                        x1={`${x}%`}
                        y1={`${y}%`}
                        x2={`${((index + 1) / (data.length - 1)) * 100}%`}
                        y2={`${100 - ((data[index + 1].value - minValue) / range) * 100}%`}
                        stroke="#3b82f6"
                        strokeWidth="2"
                      />
                    )}
                    
                    {/* Data point */}
                    <circle
                      cx={`${x}%`}
                      cy={`${y}%`}
                      r="3"
                      fill="#3b82f6"
                      stroke="white"
                      strokeWidth="2"
                    />
                  </g>
                );
              })}
            </svg>
          </div>
          
          {/* X-axis labels */}
          <div className="absolute bottom-0 left-8 right-0 flex justify-between text-xs text-slate-500 pt-2">
            <span>{new Date(data[0]?.timestamp).toLocaleTimeString()}</span>
            <span>{new Date(data[Math.floor(data.length / 2)]?.timestamp).toLocaleTimeString()}</span>
            <span>{new Date(data[data.length - 1]?.timestamp).toLocaleTimeString()}</span>
          </div>
        </div>
        
        {/* Legend */}
        <div className="mt-4 flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-slate-600">Predicted Values</span>
          </div>
          <div className="text-slate-500">
            {data.length} data points • 15-minute intervals
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GrafanaChart;