import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from '@/components/ui/use-toast';
import FileUpload from './FileUpload';
import ColumnMapping from './ColumnMapping';
import ModelSelector from './ModelSelector';
import ForecastResults from './ForecastResults';
import { parseCSV, readFileAsText, CSVRow } from '@/utils/csvParser';
import { runForecastModel, generateValidationDataWithCalculatedValue } from '@/utils/forecastService';
import { RefreshCw, Zap } from 'lucide-react';

interface AccuracyMetrics {
  rmse: number;
  mae: number;
  mape: number;
}

interface ObjectResult {
  id: string;
  metrics: AccuracyMetrics;
  chartUrl: string;
}

const NetworkKPIApp: React.FC = () => {
  const [uploadMode, setUploadMode] = useState<'single' | 'split'>('single');
  const [singleFile, setSingleFile] = useState<File | null>(null);
  const [trainFile, setTrainFile] = useState<File | null>(null);
  const [forecastFile, setForecastFile] = useState<File | null>(null);
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvData, setCsvData] = useState<CSVRow[]>([]);
  const [csvPreview, setCsvPreview] = useState<CSVRow[]>([]);
  const [dateColumn, setDateColumn] = useState<string>('');
  const [kpiColumn, setKpiColumn] = useState<string>('');
  const [identifierColumns, setIdentifierColumns] = useState<string[]>([]);
  const [trainPercentage, setTrainPercentage] = useState<number>(80);
  const [selectedModel, setSelectedModel] = useState<string>('arima');
  const [overallAccuracy, setOverallAccuracy] = useState<AccuracyMetrics | null>(null);
  const [objectResults, setObjectResults] = useState<ObjectResult[]>([]);
  const [selectedObject, setSelectedObject] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  const [validationData, setValidationData] = useState<CSVRow[]>([]);
  const [forecastKey, setForecastKey] = useState<number>(0);

  const handleFileUpload = async (files: FileList | null, type: 'single' | 'train' | 'forecast') => {
    if (!files || files.length === 0) return;
    const file = files[0];
    setError('');
    try {
      const csvText = await readFileAsText(file);
      const { headers, data } = parseCSV(csvText);
      if (type === 'single') {
        setSingleFile(file);
        setCsvHeaders(headers);
        setCsvData(data);
        setCsvPreview(data.slice(0, 5));
      } else if (type === 'train') {
        setTrainFile(file);
        setCsvHeaders(headers);
        setCsvData(data);
        setCsvPreview(data.slice(0, 5));
      } else if (type === 'forecast') {
        setForecastFile(file);
      }
      toast({ title: "File uploaded successfully", description: `${file.name} has been processed.` });
    } catch (err) {
      setError('Error reading CSV file. Please check the format.');
      toast({ title: "Upload failed", description: "Please check your CSV file format.", variant: "destructive" });
    }
  };

  const handleRunForecast = async () => {
    if (!dateColumn || !kpiColumn) {
      setError('Please select both datetime and KPI columns.');
      return;
    }
    if (csvData.length === 0) {
      setError('Please upload a CSV file first.');
      return;
    }
    if (!selectedModel) {
      setError('Please select a forecasting model.');
      return;
    }
    setIsLoading(true);
    setError('');
    
    try {
      const result = await runForecastModel({
        model: selectedModel,
        data: csvData,
        dateColumn,
        kpiColumn,
        forecastPeriods: 288,
        trainPercentage: uploadMode === 'single' ? trainPercentage : undefined
      });
      
      if (result.validationData && result.validationData.length > 0) {
        const validationWithCalculatedValue = generateValidationDataWithCalculatedValue(
          result.validationData,
          dateColumn,
          kpiColumn,
          identifierColumns
        );
        setValidationData(validationWithCalculatedValue);
      }
      
      setOverallAccuracy(result.metrics);
      
      const uniqueObjects = identifierColumns.length > 0 
        ? [...new Set(csvData.map(row => 
            identifierColumns.map(col => row[col]).filter(val => val && val.trim()).join('-')
          ))].filter(id => id && id !== '')
        : ['default'];
      
      const objectResultsWithIds: ObjectResult[] = uniqueObjects.map(objectId => ({
        id: objectId,
        metrics: result.metrics,
        chartUrl: ''
      }));
      
      setObjectResults(objectResultsWithIds);
      setSelectedObject(uniqueObjects[0] || 'default');
      setForecastKey(prev => prev + 1);
      
      toast({ 
        title: "Forecast completed", 
        description: `Your ${selectedModel.toUpperCase()} forecast has been generated.` 
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Error running forecast. Please try again.';
      setError(errorMessage);
      toast({ title: "Forecast failed", description: errorMessage, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadResults = () => {
    try {
      const resultsData = {
        model: selectedModel,
        overallAccuracy,
        objectResults,
        metadata: {
          dateColumn,
          kpiColumn,
          identifierColumns,
          trainPercentage: uploadMode === 'single' ? trainPercentage : undefined,
          totalValidationRecords: validationData.length,
          generatedAt: new Date().toISOString()
        }
      };
      const jsonString = JSON.stringify(resultsData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `forecast_results_${selectedModel}_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Download started", description: "Your results are being downloaded as a JSON file." });
    } catch (error) {
      toast({ title: "Download failed", description: "There was an error downloading your results.", variant: "destructive" });
    }
  };

  const handleDownloadPredictions = () => {
    try {
      if (validationData.length === 0) {
        toast({ title: "No validation data available", description: "Please run a forecast first to generate validation data.", variant: "destructive" });
        return;
      }
      const headers = Object.keys(validationData[0]);
      const csvContent = [
        headers.join(','),
        ...validationData.map(row => 
          headers.map(header => {
            const value = row[header];
            if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
              return `"${value.replace(/"/g, '""')}"`;
            }
            return value;
          }).join(',')
        )
      ].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `validation_data_${selectedModel}_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      toast({ title: "Download started", description: `Your validation data with calculated values (${validationData.length} records) is being downloaded.` });
    } catch (error) {
      toast({ title: "Download failed", description: "There was an error downloading your validation data.", variant: "destructive" });
    }
  };

  const handleReset = () => {
    setSingleFile(null);
    setTrainFile(null);
    setForecastFile(null);
    setCsvHeaders([]);
    setCsvData([]);
    setCsvPreview([]);
    setDateColumn('');
    setKpiColumn('');
    setIdentifierColumns([]);
    setTrainPercentage(80);
    setSelectedModel('arima');
    setOverallAccuracy(null);
    setObjectResults([]);
    setSelectedObject('');
    setValidationData([]);
    setError('');
    setForecastKey(0);
    toast({ title: "Reset complete", description: "All data has been cleared." });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-8">
      <div className="max-w-4xl mx-auto px-4 space-y-8">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Network KPI Forecasting
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Upload your time-series data, select a forecasting model, and generate accurate KPI forecasts.
          </p>
        </div>
        {error && (
          <Alert className="border-red-200 bg-red-50">
            <AlertDescription className="text-red-700">{error}</AlertDescription>
          </Alert>
        )}
        <FileUpload
          uploadMode={uploadMode}
          setUploadMode={setUploadMode}
          onFileUpload={handleFileUpload}
          trainFile={trainFile}
          forecastFile={forecastFile}
          singleFile={singleFile}
        />
        <ColumnMapping
          headers={csvHeaders}
          dateColumn={dateColumn}
          setDateColumn={setDateColumn}
          kpiColumn={kpiColumn}
          setKpiColumn={setKpiColumn}
          identifierColumns={identifierColumns}
          setIdentifierColumns={setIdentifierColumns}
          trainPercentage={trainPercentage}
          setTrainPercentage={setTrainPercentage}
          uploadMode={uploadMode}
          csvPreview={csvPreview}
        />
        {csvHeaders.length > 0 && (
          <ModelSelector
            selectedModel={selectedModel}
            onModelChange={setSelectedModel}
          />
        )}
        {csvHeaders.length > 0 && (
          <div className="flex flex-wrap gap-4 justify-center">
            <Button
              onClick={handleRunForecast}
              disabled={isLoading || !dateColumn || !kpiColumn || !selectedModel}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 text-lg font-semibold shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Running {selectedModel.toUpperCase()}...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Run {selectedModel.toUpperCase()} Forecast
                </div>
              )}
            </Button>
            <Button
              onClick={handleReset}
              variant="outline"
              className="border-slate-300 text-slate-700 hover:bg-slate-50 px-6 py-3"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>
        )}
        <ForecastResults
          key={forecastKey}
          overallAccuracy={overallAccuracy}
          objectResults={objectResults}
          selectedObject={selectedObject}
          setSelectedObject={setSelectedObject}
          onDownloadResults={handleDownloadResults}
          onDownloadPredictions={handleDownloadPredictions}
          isLoading={isLoading}
          predictedData={validationData}
          selectedModel={selectedModel}
        />
      </div>
    </div>
  );
};

export default NetworkKPIApp;