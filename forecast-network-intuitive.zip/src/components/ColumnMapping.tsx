import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Info } from 'lucide-react';

interface ColumnMappingProps {
  headers: string[];
  dateColumn: string;
  setDateColumn: (column: string) => void;
  kpiColumn: string;
  setKpiColumn: (column: string) => void;
  identifierColumns: string[];
  setIdentifierColumns: (columns: string[]) => void;
  trainPercentage: number;
  setTrainPercentage: (percentage: number) => void;
  uploadMode: 'single' | 'split';
  csvPreview: any[];
}

const ColumnMapping: React.FC<ColumnMappingProps> = ({
  headers,
  dateColumn,
  setDateColumn,
  kpiColumn,
  setKpiColumn,
  identifierColumns,
  setIdentifierColumns,
  trainPercentage,
  setTrainPercentage,
  uploadMode,
  csvPreview
}) => {
  const handleIdentifierChange = (column: string, checked: boolean) => {
    if (checked) {
      setIdentifierColumns([...identifierColumns, column]);
    } else {
      setIdentifierColumns(identifierColumns.filter(col => col !== column));
    }
  };

  if (headers.length === 0) return null;

  return (
    <Card className="bg-white shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-t-lg">
        <CardTitle className="text-xl font-bold text-slate-800">2. Map Columns</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* CSV Preview */}
          {csvPreview.length > 0 && (
            <div className="space-y-2">
              <Label className="text-sm font-medium text-slate-700">Data Preview (First 5 rows)</Label>
              <div className="overflow-x-auto border rounded-lg">
                <table className="min-w-full text-sm">
                  <thead className="bg-slate-50">
                    <tr>
                      {headers.map((header, idx) => (
                        <th key={idx} className="px-3 py-2 text-left font-medium text-slate-700 border-b">
                          {header}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {csvPreview.slice(0, 5).map((row, idx) => (
                      <tr key={idx} className="border-b">
                        {headers.map((header, colIdx) => (
                          <td key={colIdx} className="px-3 py-2 text-slate-600">
                            {row[header]}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Column Selectors */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-sm font-medium text-slate-700">DateTime Column</Label>
              <Select value={dateColumn} onValueChange={setDateColumn}>
                <SelectTrigger className="border-indigo-200 focus:border-indigo-400">
                  <SelectValue placeholder="Select datetime column" />
                </SelectTrigger>
                <SelectContent>
                  {headers.map((header) => (
                    <SelectItem key={header} value={header}>{header}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-medium text-slate-700">KPI Column</Label>
              <Select value={kpiColumn} onValueChange={setKpiColumn}>
                <SelectTrigger className="border-indigo-200 focus:border-indigo-400">
                  <SelectValue placeholder="Select KPI column" />
                </SelectTrigger>
                <SelectContent>
                  {headers.map((header) => (
                    <SelectItem key={header} value={header}>{header}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Identifier Columns */}
          <div className="space-y-2">
            <Label className="text-sm font-medium text-slate-700">Identifier Columns (for grouping)</Label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {headers.map((header) => (
                <div key={header} className="flex items-center space-x-2">
                  <Checkbox
                    id={header}
                    checked={identifierColumns.includes(header)}
                    onCheckedChange={(checked) => handleIdentifierChange(header, checked as boolean)}
                    className="text-indigo-600"
                  />
                  <Label htmlFor={header} className="text-sm text-slate-600">{header}</Label>
                </div>
              ))}
            </div>
          </div>

          {/* Training Percentage Slider */}
          {uploadMode === 'single' && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Label className="text-sm font-medium text-slate-700">
                  Training Data Percentage: {trainPercentage}%
                </Label>
                <Info className="w-4 h-4 text-slate-500" />
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-700">
                  <strong>{trainPercentage}%</strong> of your data will be used to train the model. 
                  The remaining <strong>{100 - trainPercentage}%</strong> will be used for validation and exported with calculated values.
                </p>
              </div>
              <Slider
                value={[trainPercentage]}
                onValueChange={(value) => setTrainPercentage(value[0])}
                max={90}
                min={50}
                step={5}
                className="w-full"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ColumnMapping;