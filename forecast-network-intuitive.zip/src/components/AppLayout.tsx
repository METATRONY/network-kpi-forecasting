import React from 'react';
import NetworkKPIApp from './NetworkKPIApp';
import { Toaster } from '@/components/ui/toaster';

const AppLayout: React.FC = () => {
  return (
    <>
      <NetworkKPIApp />
      <Toaster />
    </>
  );
};

export default AppLayout;