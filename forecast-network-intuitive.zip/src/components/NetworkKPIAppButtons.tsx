import React from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw, Zap } from 'lucide-react';

interface NetworkKPIAppButtonsProps {
  isLoading: boolean;
  selectedModel: string;
  dateColumn: string;
  kpiColumn: string;
  onRunForecast: () => void;
  onReset: () => void;
}

const NetworkKPIAppButtons: React.FC<NetworkKPIAppButtonsProps> = ({
  isLoading,
  selectedModel,
  dateColumn,
  kpiColumn,
  onRunForecast,
  onReset
}) => {
  return (
    <div className="flex flex-wrap gap-4 justify-center">
      <Button
        onClick={onRunForecast}
        disabled={isLoading || !dateColumn || !kpiColumn || !selectedModel}
        className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 text-lg font-semibold shadow-lg"
      >
        {isLoading ? (
          <div className="flex items-center gap-2">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            Running {selectedModel.toUpperCase()}...
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Run {selectedModel.toUpperCase()} Forecast
          </div>
        )}
      </Button>
      <Button
        onClick={onReset}
        variant="outline"
        className="border-slate-300 text-slate-700 hover:bg-slate-50 px-6 py-3"
      >
        <RefreshCw className="w-4 h-4 mr-2" />
        Reset
      </Button>
    </div>
  );
};

export default NetworkKPIAppButtons;