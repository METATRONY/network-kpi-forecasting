import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';

interface FileUploadProps {
  uploadMode: 'single' | 'split';
  setUploadMode: (mode: 'single' | 'split') => void;
  onFileUpload: (files: FileList | null, type: 'single' | 'train' | 'forecast') => void;
  trainFile: File | null;
  forecastFile: File | null;
  singleFile: File | null;
}

const FileUpload: React.FC<FileUploadProps> = ({
  uploadMode,
  setUploadMode,
  onFileUpload,
  trainFile,
  forecastFile,
  singleFile
}) => {
  return (
    <Card className="bg-white shadow-lg border-0">
      <CardHeader className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-t-lg">
        <CardTitle className="text-xl font-bold text-slate-800">1. Upload Your Data</CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          <RadioGroup value={uploadMode} onValueChange={(value) => setUploadMode(value as 'single' | 'split')}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="single" id="single" className="text-indigo-600" />
              <Label htmlFor="single" className="text-slate-700 font-medium">Single CSV file (split automatically)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="split" id="split" className="text-indigo-600" />
              <Label htmlFor="split" className="text-slate-700 font-medium">Separate train/forecast files</Label>
            </div>
          </RadioGroup>

          {uploadMode === 'single' ? (
            <div className="space-y-2">
              <Label htmlFor="single-file" className="text-sm font-medium text-slate-700">Upload CSV File</Label>
              <Input
                id="single-file"
                type="file"
                accept=".csv"
                onChange={(e) => onFileUpload(e.target.files, 'single')}
                className="border-2 border-dashed border-indigo-200 hover:border-indigo-300 transition-colors"
              />
              {singleFile && (
                <p className="text-sm text-green-600 font-medium">✓ {singleFile.name}</p>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="train-file" className="text-sm font-medium text-slate-700">Training Data</Label>
                <Input
                  id="train-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => onFileUpload(e.target.files, 'train')}
                  className="border-2 border-dashed border-indigo-200 hover:border-indigo-300 transition-colors"
                />
                {trainFile && (
                  <p className="text-sm text-green-600 font-medium">✓ {trainFile.name}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="forecast-file" className="text-sm font-medium text-slate-700">Forecast Data</Label>
                <Input
                  id="forecast-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => onFileUpload(e.target.files, 'forecast')}
                  className="border-2 border-dashed border-indigo-200 hover:border-indigo-300 transition-colors"
                />
                {forecastFile && (
                  <p className="text-sm text-green-600 font-medium">✓ {forecastFile.name}</p>
                )}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default FileUpload;