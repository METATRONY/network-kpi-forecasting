import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://shqobkazwnejjbtuyxhn.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNocW9ia2F6d25lampidHV5eGhuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE4NzcwMTQsImV4cCI6MjA2NzQ1MzAxNH0.hpw4L45s2amw11peBJi6lzDa7Bd7sMcWjZKtRA2AOcs';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };